package Data;

import java.util.List;

public class Person {

	/**
	 * 
	 */
	public List<String> hobbies;
	/**
	 * 
	 */
	public int age;
	/**
	 * 
	 */
	public String name;
	/**
	 * 
	 */
	public char gender;
	/**
	 * Getter of hobbies
	 */
	public List<String> getHobbies() {
	 	 return hobbies; 
	}
	/**
	 * Setter of hobbies
	 */
	public void setHobbies(List<String> hobbies) { 
		 this.hobbies = hobbies; 
	}
	/**
	 * Getter of age
	 */
	public int getAge() {
	 	 return age; 
	}
	/**
	 * Setter of age
	 */
	public void setAge(int age) { 
		 this.age = age; 
	}
	/**
	 * Getter of name
	 */
	public String getName() {
	 	 return name; 
	}
	/**
	 * Setter of name
	 */
	public void setName(String name) { 
		 this.name = name; 
	}
	/**
	 * 
	 * @param viewInfo 
	 * @return 
	 */
	public String printInfo(String viewInfo) { 
		// TODO Auto-generated method
		return null;
	 }
	/**
	 * Getter of gender
	 */
	public char getGender() {
	 	 return gender; 
	}
	/**
	 * Setter of gender
	 */
	public void setGender(char gender) { 
		 this.gender = gender; 
	} 

}
