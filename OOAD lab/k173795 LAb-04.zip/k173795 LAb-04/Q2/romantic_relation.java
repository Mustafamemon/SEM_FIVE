

public class romantic_relation extends friendship { 

}