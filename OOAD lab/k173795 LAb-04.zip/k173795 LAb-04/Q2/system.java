

public class system { 

}