

public class paid_plugin extends third_party_plugin { 

}