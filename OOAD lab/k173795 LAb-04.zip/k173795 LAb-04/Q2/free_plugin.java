

public class free_plugin extends third_party_plugin { 

}