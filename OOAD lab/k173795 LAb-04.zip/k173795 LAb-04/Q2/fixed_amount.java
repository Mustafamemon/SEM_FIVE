

public class fixed_amount extends paid_plugin { 

}