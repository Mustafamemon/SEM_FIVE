

public class third_party_plugin {

	/**
	 * 
	 */
	public void  display_pictures () { 
		// TODO Auto-generated method
	 }

	/**
	 * 
	 */
	public void maintain_calendar() { 
		// TODO Auto-generated method
	 } 

}