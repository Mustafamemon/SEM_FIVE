

public class family_relation extends friendship { 

}