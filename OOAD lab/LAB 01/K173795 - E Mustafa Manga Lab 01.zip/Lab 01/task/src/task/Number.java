package task;

public class Number {
	public int addingNumber(int a , int b) {
		return a+b; 
	}
	public int addingNumber(int a , int b , int c) {
		return a+b+c; 
	}
}
