package task;

public class Animal {

	private String animalSound ;

	public String getAnimalSound() {
		return animalSound;
	}

	public void setAnimalSound(String animalSound) {
		this.animalSound = animalSound;
	}
	

}
